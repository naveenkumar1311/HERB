#!/usr/bin/env python
# coding: utf-8

# In[69]:


import matplotlib
import matplotlib.pyplot as plt
import numpy as np



# l1=  (4.24, 8.63, 1.75,1.94,8.08,2.04)
# l2=  (4.23,9.60,1.69,1.75,8.33,1.85)
# l3=  (4.07,8.16,1.70,1.80,8.09,2.08)
# l4=  (8.89, 13.3, 6.03,4.8,9.93,5.86)
# l5=  (9.2,13.25,5.83,3.63,12.27,6.07)
# l6=  (9.11,13.76,4.77,3.65,13.83,4.69)


l1=   (4.24, 1.94, 2.04)
l2=  (4.22,1.75,1.85)
l3=  (4.07,1.80,2.08)


# l1=   (5.02, 1.28, 14.7)
# l2=  (3.35,1.45,6.64)
# l3=  (3.72,1.65,5.31)

# l1=   (2.34, 1.55, 4.66)
# l2=  (7.04,1.24,1.84)
# l3=  (9.64,0.79,2.76)

patterns = [ "||--" , "-" , "x" , "+" , "-", ".", "*","x", "o", "O" ]

ind = np.arange(len(l1))  # the x locations for the groups
print ind
width = 0.25  # the width of the bars


fig, ax = plt.subplots(figsize= (10,5))
rects1 = ax.bar(ind - width, l1, width,
                label='ATAT for Additive HERB', hatch = patterns[0])
rects2 = ax.bar(ind - width, l2, width,
                label='ATAT for Multiplicative HERB', hatch = patterns[1])
rects3 = ax.bar(ind - width , l3, width,
                label='ATAT for Static HERB', hatch = patterns[2])
rects4 = ax.bar(ind, l4, width,
                label='ATAT for WFS', hatch = patterns[3])
rects5 = ax.bar(ind + width, l5, width,
                label='ATAT for FCFS', hatch = patterns[4])
rects6 = ax.bar(ind +  width, l6, width,
                label='ATAT for SJF', hatch = patterns[5])

# Add some text for labels, title and custom x-axis tick labels, etc.
ax.set_ylabel('Average Turn Around Time (ms)')
ax.set_xlabel('Testcases')
#ax.set_title('Graph')
ax.set_xticks(ind)
ax.set_xticklabels(('Testcase1','Testcase2A','Testcase2B', 'Testcase3A','Testcase3B', 'Testcase4'))
ax.legend()


def autolabel(rects, xpos='center'):
   
    ha = {'center': 'center', 'right': 'left', 'left': 'right'}
    offset = {'center': 0, 'right': 1, 'left': -1}

    for rect in rects:
        height = rect.get_height()
        # ax.annotate('{}'.format(height),
        #             xy=(rect.get_x() + rect.get_width()/1.5, height),
        #             xytext=(offset[xpos], 0),  # use 3 points offset
        #             textcoords="offset points",  # in both directions
        #             ha=ha[xpos], va='bottom')


autolabel(rects1, "left")
autolabel(rects2, "left")
autolabel(rects3, 'left')
autolabel(rects4, "right")
autolabel(rects5, "right")
autolabel(rects6, 'center')
fig.tight_layout()


plt.show()


# In[ ]:





# In[ ]:





# In[ ]:




