#!/usr/bin/env python
# coding: utf-8

# In[157]:


import matplotlib
import matplotlib.pyplot as plt
import numpy as np


l1= (4.53,14.23,24.29)
l2= (8.30,19.72,34.2)
l3= (8.37,21.84,37.5)
l4=(0,0,0)
l5= (33.13,62.6,96.3)
l6= (22.16,60.12,93.5)
l7= (25.85,68.32,95.05)

patterns = [ "||-" , "o" , "\\//" , "*" , ".", "O", "x","x", "o", "O"]

ind = np.arange(len(l1))   # the x locations for the groups
ind = np.array([1,5,9,13,17,21])
width = 0.60# the width of the bars


fig, ax = plt.subplots(figsize= (15,5))
rects1 = ax.bar(ind - 3*width + width/2, l1, width,
                label='HERB ATAT', hatch = patterns[0], color = 'w', edgecolor = 'black',linewidth = 1.5)
rects2 = ax.bar(ind - 2*width + width/2, l2, width,
                label='SJF ATAT', hatch = patterns[1], color = 'w',edgecolor = 'black',linewidth = 1.5)
rects3 = ax.bar(ind - width+width/2, l3, width,
                label='FCFS ATAT', hatch = patterns[2],  color = 'w',edgecolor = 'black', linewidth=1.5)

rects4 = ax.bar(ind - width+width/2, l4, width,
                hatch = "6",  color = 'w',edgecolor = 'black', linewidth=1.5)

rects5 = ax.bar(ind + width - width/2, l5, width,
                label='HERB AWT', hatch = patterns[3], color = 'w',edgecolor = 'black',linewidth = 1.5)
rects6 = ax.bar(ind +  2*width - width/2, l6, width,
                label='SJF AWT', hatch = patterns[4], color = 'w',edgecolor = 'black',linewidth = 1.5 )
rects7 = ax.bar(ind +  3*width - width/2, l7, width,
                label='FCFS AWT', hatch = patterns[5], color = 'w',edgecolor = 'black',linewidth = 1.5)

# Add some text for labels, title and custom x-axis tick labels, etc.
ax.set_ylabel('Time (ms)')
ax.set_xlabel('Number of Tasks')
ax.set_xticks(ind)
ax.set_xticklabels(('100', '500', '1000'))
ax.legend()


def autolabel(rects, xpos='center'):
    """
    Attach a text label above each bar in *rects*, displaying its height.

    *xpos* indicates which side to place the text w.r.t. the center of
    the bar. It can be one of the following {'center', 'right', 'left'}.
    """

    ha = {'center': 'center', 'right': 'left', 'left': 'right'}
    offset = {'center': 0, 'right': 1, 'left': -1}

    for rect in rects:
        height = rect.get_height()
        ax.annotate('{0:.1f}'.format((height)),
                    xy=(rect.get_x() + rect.get_width() / 2, height),
                    xytext=(offset[xpos]*3, 3),  # use 3 points offset
                    textcoords="offset points",  # in both directions
                    ha=ha[xpos], va='bottom')


autolabel(rects1)
autolabel(rects2 )
autolabel(rects3)
autolabel(rects4, 'center')
autolabel(rects5)
autolabel(rects6 )
autolabel(rects7, 'center')
fig.tight_layout()

plt.show()


# In[155]:


# import matplotlib
# import matplotlib.pyplot as plt
# import numpy as np


# l1=   [4.24, 1.75, 8.08]
# l2=  [4.23,1.69,8.33]
# l3=  [4.07,1.70,8.09]

# patterns = [ "|" , "\\" , "/" , "+" , "-", ".", "*","x", "o", "O", ]

# ind = np.arange(len(l1))   # the x locations for the groups
# ind = np.array([1,3,5])
# width = 0.5# the width of the bars


# fig, ax = plt.subplots(figsize= (10,7))
# rects1 = ax.bar(ind - width , l1, width,
#                 label='ATAT for Addtive HERB', hatch = patterns[-1], color = 'w', edgecolor = 'black',linewidth = 4)
# rects2 = ax.bar(ind , l2, width,
#                 label='ATAT for Multiplicative HERB', hatch = patterns[2], color = 'w',edgecolor = 'black',linewidth = 4)
# rects3 = ax.bar(ind + width, l3, width,
#                 label='ATAT for Static HERB', hatch = patterns[-4],  color = 'w',edgecolor = 'black', linewidth = 4)


# # Add some text for labels, title and custom x-axis tick labels, etc.
# ax.set_ylabel('Results')
# ax.set_title('TestCases')
# ax.set_xticks(ind)
# ax.set_xticklabels(('Testcase1', 'Testcase2B', 'Testcase3B', 'G4', 'G5','G6'))
# ax.legend()


# def autolabel(rects, xpos='center'):
#     """
#     Attach a text label above each bar in *rects*, displaying its height.

#     *xpos* indicates which side to place the text w.r.t. the center of
#     the bar. It can be one of the following {'center', 'right', 'left'}.
#     """

#     ha = {'center': 'center', 'right': 'left', 'left': 'right'}
#     offset = {'center': 0, 'right': 1, 'left': -1}

#     for rect in rects:
#         height = rect.get_height()
#         ax.annotate('{0:.1f}'.format((height)),
#                     xy=(rect.get_x() + rect.get_width() / 2, height),
#                     xytext=(offset[xpos]*3, 3),  # use 3 points offset
#                     textcoords="offset points",  # in both directions
#                     ha=ha[xpos], va='bottom')


# autolabel(rects1)
# autolabel(rects2 )
# autolabel(rects3, 'center')

# fig.tight_layout()

# plt.show()

