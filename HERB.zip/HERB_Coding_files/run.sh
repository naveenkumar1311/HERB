#!/bin/bash


for f in Testcasesall/*;
do
    python DAC_final.py $f
done

for f in Testcasesall/*;
do
    python FCFS_final.py $f
done

for f in Testcasesall/*;
do
    python SJF_final.py $f
done