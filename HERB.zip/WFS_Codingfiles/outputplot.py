#Output plot file comparing the standard FCFS and DAC Algorithm

inputdata1={}
filename = raw_input("Give the name of the input file : ") 
#**************************
with open(filename,'r') as input_file:
        for line in input_file:
                if not line.startswith('#'):
                        splitline=line.split(",")
                        inputdata1[str(splitline[0])]=",".join(splitline[1:])                         
        for key in inputdata1:
                inputdata1[key]=inputdata1[key].rstrip()
                inputdata1[key]=list(inputdata1[key].split(","))

def insertionsort(list1,list2):
     for index in range(1,len(list1)):
             value1=list1[index]
             value2=list2[index]
             i = index-1
             while i >= 0:
                     if value1 < list1[i]:
                             list1[i+1] = list1[i]
                             list2[i+1] = list2[i]
                             list1[i] = value1
                             list2[i] = value2
                             i = i-1
                     else:
                             break

l1=[int(v[7]) for k,v in inputdata1.items() if len(v)==8 ] #contains priority1 list of Tasks
keyArray=[int(v[0])  for k,v in inputdata1.items() if len(v)==8]         #contains corresponding Tasks
k1=[k for k,v in inputdata1.items() if len(v)==8]
insertionsort(l1,keyArray) #calling insertionsort to sort based on priority1
l1=[int(v[7]) for k,v in inputdata1.items() if len(v)==8 ] #contains priority1 list of Tasks
insertionsort(l1,k1) #calling insertionsort to sort based on priority1
p=1
priority1={}
i=0
j=i
while(i<len(l1)-1):
        temp=[]
        j=i
        while l1[j]==p and j<len(l1):
                temp.append(keyArray[j])
                if(j<len(l1)-1):
                        j=j+1
                else:
                        break
        i=j
        priority1[p]=temp
        p=p+1

print priority1
#**********************
p=1
priority2={}
i=0
j=i
while(i<len(l1)-1):
        temp=[]
        j=i
        while l1[j]==p and j<len(l1):
                temp.append(k1[j])
                if(j<len(l1)-1):
                        j=j+1
                else:
                        break
        i=j
        priority2[p]=temp
        p=p+1

print priority2


#**************************
filename1 = 'outputDAC'+filename

count=0
inputdata={}

with open(filename1,'r') as input_file:

        for line in input_file:

                splitline=line.split(",")

                inputdata[count]=",".join(splitline[0:])
                
                count=count+1    
    


filename2 = 'outputFCFS'+filename


with open(filename2,'r') as input_file:

        for line in input_file:

                splitline=line.split(",")

                inputdata[count]=",".join(splitline[0:]) 
                
                count=count+1   
    
        
filename3 = 'outputSJF'+filename


with open(filename3,'r') as input_file:

        for line in input_file:

                splitline=line.split(",")

                inputdata[count]=",".join(splitline[0:]) 
                
                count=count+1   
    
        for key in inputdata:

                inputdata[key]=inputdata[key].rstrip()

                inputdata[key]=list(inputdata[key].split(","))
   




Tasks=[i for i in range(len(inputdata[0]))]
TTAT1=map(int,inputdata[0])
TWT1=map(int,inputdata[1])
TExecTime1=map(int,inputdata[2])

TTAT2=map(int,inputdata[3])
TWT2=map(int,inputdata[4])
TExecTime2=map(int,inputdata[5])


TTAT3=map(int,inputdata[6])
TWT3=map(int,inputdata[7])
TExecTime3=map(int,inputdata[8])

#********************************************
ExecSumMAX={}
print k1
j=0
for k in priority2.keys():
        tempsum=0
        for i in range(len(priority2[k])):                
                tempsum=tempsum+int(inputdata1[k1[i+j]][1])
        ExecSumMAX[k]=tempsum
        j=i+j+1
print ExecSumMAX
TExecMax=[v for k,v in ExecSumMAX.items()]
#*******************************************
#********************************************
ExecSumDAC={}
for k in priority1.keys():
        tempsum=0
        for i in range(len(priority1[k])):
                tempsum=tempsum+TExecTime1[priority1[k][i]-1]
        ExecSumDAC[k]=tempsum
        
print ExecSumDAC
TExecTime1=[v for k,v in ExecSumDAC.items()]
#*******************************************

#********************************************
ExecSumFCFS={}
for k in priority1.keys():
        tempsum=0
        for i in range(len(priority1[k])):
                tempsum=tempsum+TExecTime2[priority1[k][i]-1]
        ExecSumFCFS[k]=tempsum
        
print ExecSumFCFS
TExecTime2=[v for k,v in ExecSumFCFS.items()]
#*******************************************


#********************************************
ExecSumSJF={}
for k in priority1.keys():
        tempsum=0
        for i in range(len(priority1[k])):
                tempsum=tempsum+TExecTime3[priority1[k][i]-1]
        ExecSumSJF[k]=tempsum
        
print ExecSumSJF
TExecTime3=[v for k,v in ExecSumSJF.items()]
#*******************************************



#matplotlib inline
#import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


#*****************
raw_data = {'first_name': ['priority1'+str(priority2[1]),'priority2'+str(priority2[2]),'priority3'+str(priority2[3]),'priority4'+str(priority2[4])],
        'MaxExec':TExecMax,
        'DACExec': TExecTime1,
        'FCFSExec': TExecTime2,
        'SJFExec': TExecTime3}
        #'post_score': [5, 43, 23, 23, 51]}
#raw_data = pd.DataFrame(raw_data, columns = ['first_name', 'DACExec', 'FCFSExec', 'post_score'])


# Setting the positions and width for the bars
pos = list(range(len(raw_data['DACExec'])))
#print pos
width = 0.2

# Plotting the bars
fig, ax = plt.subplots(figsize=(10,10))

# Create a bar with DACExec data,
# in position pos,
plot1=plt.bar(pos,
        #using raw_data['DACExec'] data,
        raw_data['MaxExec'],
        # of width
        width,
        # with alpha 0.5
        alpha=0.5,
        # with color
        color='#808080',
        # with label the first value in first_name
        label=raw_data['first_name'][0])

plot2=plt.bar(pos,
        #using raw_data['DACExec'] data,
        raw_data['DACExec'],
        # of width
        width,
        # with alpha 0.5
        alpha=0.5,
        # with color
        color='r',
        # with label the first value in first_name
        label=raw_data['first_name'][0])

# Create a bar with FCFSExec data,
# in position pos + some width buffer,
plt.bar([p + width for p in pos],
        #using raw_data['FCFSExec'] data,
        raw_data['MaxExec'],
        # of width
        width,
        # with alpha 0.5
        alpha=0.5,
        # with color
        color='#808080',
        # with label the second value in first_name
        label=raw_data['first_name'][1])

plot3=plt.bar([p + width for p in pos],
        #using raw_data['FCFSExec'] data,
        raw_data['FCFSExec'],
        # of width
        width,
        # with alpha 0.5
        alpha=0.5,
        # with color
        color='b',
        # with label the second value in first_name
        label=raw_data['first_name'][1])

plt.bar([p + width*2 for p in pos],
        #using raw_data['FCFSExec'] data,
        raw_data['MaxExec'],
        # of width
        width,
        # with alpha 0.5
        alpha=0.5,
        # with color
        color='#808080',
        # with label the second value in first_name
        label=raw_data['first_name'][2])


plot4=plt.bar([p + width*2 for p in pos],
        #using raw_data['FCFSExec'] data,
        raw_data['SJFExec'],
        # of width
        width,
        # with alpha 0.5
        alpha=0.5,
        # with color
        color='g',
        # with label the second value in first_name
        label=raw_data['first_name'][2])



# Set the y axis label
ax.set_ylabel('No.of Instructions')
ax.set_xlabel('Tasks')

# Set the chart's title
ax.set_title('Number of Instructions Executed of DAC,FCFS,SJF on '+filename+' out of maximum given number of instructions')

# Set the position of the x ticks
ax.set_xticks([p + 1.5 * width for p in pos])

# Set the labels for the x ticks
ax.set_xticklabels(raw_data['first_name'])

# Setting the x-axis and y-axis limits
plt.xlim(min(pos)-width, max(pos)+width*4)
plt.ylim([0, max(raw_data['DACExec'] + raw_data['FCFSExec']+ raw_data['SJFExec'])])

# Adding the legend and showing the plot
#plt.legend(['MaxExec','DACExec', 'FCFSExec','SJFExec'], loc='upper right')
plt.legend([plot1, plot2, plot3, plot4], ['MaxInstr','DACInstr', 'FCFSInstr','SJFInstr'], loc='upper right')
plt.grid()
#plt.show()

#*****************************************************************************************************

#********************************************
TTATSumDAC={}
for k in priority1.keys():
        tempsum=0
        for i in range(len(priority1[k])):
                tempsum=tempsum+TTAT1[priority1[k][i]-1]
        TTATSumDAC[k]=tempsum
        
print TTATSumDAC
TTAT1=[v for k,v in TTATSumDAC.items()]
#*******************************************

#********************************************
TTATSumFCFS={}
for k in priority1.keys():
        tempsum=0
        for i in range(len(priority1[k])):
                tempsum=tempsum+TTAT2[priority1[k][i]-1]
        TTATSumFCFS[k]=tempsum
        
print TTATSumFCFS
TTAT2=[v for k,v in TTATSumFCFS.items()]
#*******************************************


#********************************************
TTATSumSJF={}
for k in priority1.keys():
        tempsum=0
        for i in range(len(priority1[k])):
                tempsum=tempsum+TTAT3[priority1[k][i]-1]
        TTATSumSJF[k]=tempsum
        
print TTATSumSJF
TTAT3=[v for k,v in TTATSumSJF.items()]
#*******************************************


#*****************
raw_data = {'first_name': ['priority1'+str(priority2[1]),'priority2'+str(priority2[2]),'priority3'+str(priority2[3]),'priority4'+str(priority2[4])],
        'DACTTAT': TTAT1,
        'FCFSTTAT': TTAT2,
        'SJFTTAT': TTAT3}
        #'post_score': [5, 43, 23, 23, 51]}
#raw_data = pd.DataFrame(raw_data, columns = ['first_name', 'DACExec', 'FCFSExec', 'post_score'])


# Setting the positions and width for the bars
pos = list(range(len(raw_data['DACTTAT'])))
#print pos
width = 0.2

# Plotting the bars
fig, ax = plt.subplots(figsize=(10,10))

# Create a bar with DACExec data,
# in position pos,

plot2=plt.bar(pos,
        #using raw_data['DACExec'] data,
        raw_data['DACTTAT'],
        # of width
        width,
        # with alpha 0.5
        alpha=0.5,
        # with color
        color='r',
        # with label the first value in first_name
        label=raw_data['first_name'][0])

# Create a bar with FCFSExec data,
# in position pos + some width buffer,

plot3=plt.bar([p + width for p in pos],
        #using raw_data['FCFSExec'] data,
        raw_data['FCFSTTAT'],
        # of width
        width,
        # with alpha 0.5
        alpha=0.5,
        # with color
        color='b',
        # with label the second value in first_name
        label=raw_data['first_name'][1])



plot4=plt.bar([p + width*2 for p in pos],
        #using raw_data['FCFSExec'] data,
        raw_data['SJFTTAT'],
        # of width
        width,
        # with alpha 0.5
        alpha=0.5,
        # with color
        color='g',
        # with label the second value in first_name
        label=raw_data['first_name'][2])



# Set the y axis label
ax.set_ylabel('Turn Around Times')
ax.set_xlabel('Tasks')

# Set the chart's title
ax.set_title('TurnAround times Executed of DAC,FCFS,SJF on '+filename)

# Set the position of the x ticks
ax.set_xticks([p + 1.5 * width for p in pos])

# Set the labels for the x ticks
ax.set_xticklabels(raw_data['first_name'])

# Setting the x-axis and y-axis limits
plt.xlim(min(pos)-width, max(pos)+width*4)
plt.ylim([0, max(raw_data['DACTTAT'] + raw_data['FCFSTTAT']+ raw_data['SJFTTAT'])])

# Adding the legend and showing the plot
#plt.legend(['MaxExec','DACExec', 'FCFSExec','SJFExec'], loc='upper right')
plt.legend([plot2, plot3, plot4], ['DACTTAT', 'FCFSTTAT','SJFTTAT'], loc='upper right')
plt.grid()
#plt.show()

#*******************************************************************

#********************************************

#********************************************
TWTSumDAC={}
for k in priority1.keys():
        tempsum=0
        for i in range(len(priority1[k])):
                tempsum=tempsum+TWT1[priority1[k][i]-1]
        TWTSumDAC[k]=tempsum
        
#print TWTSumDAC
TWT1=[v for k,v in TWTSumDAC.items()]
#*******************************************

#********************************************
TWTSumFCFS={}
for k in priority1.keys():
        tempsum=0
        for i in range(len(priority1[k])):
                tempsum=tempsum+TWT2[priority1[k][i]-1]
        TWTSumFCFS[k]=tempsum
        
#print TWTSumFCFS
TWT2=[v for k,v in TWTSumFCFS.items()]
#*******************************************


#********************************************
TWTSumSJF={}
for k in priority1.keys():
        tempsum=0
        for i in range(len(priority1[k])):
                tempsum=tempsum+TWT3[priority1[k][i]-1]
        TWTSumSJF[k]=tempsum
        
#print TWTSumSJF
TWT3=[v for k,v in TWTSumSJF.items()]
#*******************************************


#*****************
raw_data = {'first_name': ['priority1'+str(priority2[1]),'priority2'+str(priority2[2]),'priority3'+str(priority2[3]),'priority4'+str(priority2[4])],
        'DACTWT': TWT1,
        'FCFSTWT': TWT2,
        'SJFTWT': TWT3}
        #'post_score': [5, 43, 23, 23, 51]}
#raw_data = pd.DataFrame(raw_data, columns = ['first_name', 'DACExec', 'FCFSExec', 'post_score'])


# Setting the positions and width for the bars
pos = list(range(len(raw_data['DACTWT'])))
#print pos
width = 0.2

# Plotting the bars
fig, ax = plt.subplots(figsize=(10,10))

# Create a bar with DACExec data,
# in position pos,

plot2=plt.bar(pos,
        #using raw_data['DACExec'] data,
        raw_data['DACTWT'],
        # of width
        width,
        # with alpha 0.5
        alpha=0.5,
        # with color
        color='r',
        # with label the first value in first_name
        label=raw_data['first_name'][0])

# Create a bar with FCFSExec data,
# in position pos + some width buffer,

plot3=plt.bar([p + width for p in pos],
        #using raw_data['FCFSExec'] data,
        raw_data['FCFSTWT'],
        # of width
        width,
        # with alpha 0.5
        alpha=0.5,
        # with color
        color='b',
        # with label the second value in first_name
        label=raw_data['first_name'][1])



plot4=plt.bar([p + width*2 for p in pos],
        #using raw_data['FCFSExec'] data,
        raw_data['SJFTWT'],
        # of width
        width,
        # with alpha 0.5
        alpha=0.5,
        # with color
        color='g',
        # with label the second value in first_name
        label=raw_data['first_name'][2])



# Set the y axis label
ax.set_ylabel('Waiting Times')
ax.set_xlabel('Tasks')

# Set the chart's title
ax.set_title('Waiting times Executed of DAC,FCFS,SJF on '+filename)

# Set the position of the x ticks
ax.set_xticks([p + 1.5 * width for p in pos])

# Set the labels for the x ticks
ax.set_xticklabels(raw_data['first_name'])

# Setting the x-axis and y-axis limits
plt.xlim(min(pos)-width, max(pos)+width*4)
plt.ylim([0, max(raw_data['DACTWT'] + raw_data['FCFSTWT']+ raw_data['SJFTWT'])])

# Adding the legend and showing the plot
#plt.legend(['MaxExec','DACExec', 'FCFSExec','SJFExec'], loc='upper right')
plt.legend([plot2, plot3, plot4], ['DACTWT', 'FCFSTWT','SJFTWT'], loc='upper right')
plt.grid()
#plt.show()

#*******************************************************************

