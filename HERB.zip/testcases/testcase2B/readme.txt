#Testcase2B      :       Scenario where we have large number of small tasks

#Task Specifications : Units - Time(seconds) ; RAM (GigaBytes) ; Size  (GigaBytes) ; Deadline (seconds)

#Ranges taken while randomly generating the tasks

NUMBER OF INSTRUCTIONS  :  [1,300] 

RAM                     :  [1,4]

SIZE                    :  [100,400]       

ARRIVAL TIME            :  [0,3]   

BURSTTIME               :  [1,4]

DEADLINE                :  [1,5]

PRIORITY                :  [1,4]
