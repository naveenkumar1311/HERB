#Testcase1      :       Scenario where when a large number of tasks with competing deadlines have similar requirements as the hostmachines(overloaded condition.)

#Task Specifications : Units - Time(seconds) ; RAM (GigaBytes) ; Size  (GigaBytes) ; Deadline (seconds)

#Ranges taken while randomly generating the tasks


NUMBER OF INSTRUCTIONS  :  [800,1000] 

RAM                     :  [6,10]

SIZE                    :  [800,1000]       

ARRIVAL TIME            :  [0,3]   

BURSTTIME               :  [1,10]

DEADLINE                :  [5,8]

PRIORITY                :  [1,4]
