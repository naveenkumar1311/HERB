#Testcase4      :       Scenario where we have underloaded tasks

#Task Specifications : Units - Time(seconds) ; RAM (GigaBytes) ; Size  (GigaBytes) ; Deadline (seconds)

#Ranges taken while randomly generating the tasks


NUMBER OF INSTRUCTIONS  :  [100,300] 

RAM                     :  [1,3]

SIZE                    :  [200,400]       

ARRIVAL TIME            :  [0,3]   

BURSTTIME               :  [1,3]

DEADLINE                :  [3,4]

PRIORITY                :  [1,4]
