#Testcase3B      :       Scenario where we have large number of large tasks

#Task Specifications : Units - Time(seconds) ; RAM (GigaBytes) ; Size  (GigaBytes) ; Deadline (seconds)

#Ranges taken while randomly generating the tasks


NUMBER OF INSTRUCTIONS  :  [1000,1500] 

RAM                     :  [10,15]

SIZE                    :  [900,1000]       

ARRIVAL TIME            :  [0,3]   

BURSTTIME               :  [8,15]

DEADLINE                :  [9,13]

PRIORITY                :  [1,4]
