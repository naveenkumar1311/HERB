#testcases generator
#Name : K Naveen Kumar
#Date : 29-6-2017

#*******************************
from random import randint

n=int(raw_input("Give the number of tasks to be generated:"))
m=raw_input('Give the name of the testcase:')
inputdata={}
#********************************
filename=m+'_tasks'+str(n)+'.txt'

for i in range(n):
        data=[]
        #taskname
        data.append('T'+str(i+1)) 
        #taskid
        data.append(i+1)
        #number of instructions
        temp=randint(100,300) 
        data.append(temp)
        #ram 
        temp=randint(1,3)  
        data.append(temp)    
        #size
        temp=randint(200,400)  
        data.append(temp)
        #arrivaltime
        temp=randint(0,3)  
        data.append(temp)
        #bursttime
        temp=randint(1,3)  
        data.append(temp)
        #deadline
        temp=randint(3,4)  
        data.append(temp)
        #priority
        temp=randint(1,4)  
        data.append(temp)
        
        #print data,len(data)
        with open(filename,'a') as output_file:
                 output_file.write("%s,"%data[0])
                 for i in range(1,len(data)):
                
                        if i<len(data)-1:
                
                                output_file.write("%d," %data[i])
                        
                        else :
                
                                output_file.write("%d\n" %data[i])
                 output_file.write('\n')
                
        del(data)
